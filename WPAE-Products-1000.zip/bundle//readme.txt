The other two files in this zip are the export file containing all of your data and the import template for WP All Import. 

To import this data, create a new import with WP All Import and upload this zip file.